package com.pipe1013.fundamentoskotlin2.Apuntes

class List {
}

fun main() {
    /*var instruments = listOf("trumpet", "piano", "violin")
    println("Esta es una lista inmutable...")
    println(instruments)

    var myList = mutableListOf("trumpet", "piano", "violin")
    println("Esta es una lista mutable...")
    println(myList)


    for ((index,elements) in instruments.withIndex())
        println("La mascota No. $index es $elements")*/

    //Crear lista mutable
    var instruments = listOf("trumpet", "piano", "violin")

    //Obtener el primer elemento de la lista
    var firstElement = instruments.first()

    //Obtener el ultimo elemento de la lista
    var lastElement = instruments.last()

    //Imprimir resultados
    println("El primer elemento de la lista es $firstElement")
    println("El primer elemento de la lista es $lastElement")

    println("---------------------------------------------------------------")

    var listMutable = mutableListOf<Int>()

    //Agregar elementos a una lista mutable
    listMutable.add(1)
    listMutable.add(2)
    listMutable.add(3)

    //Imprimimr lista mutable
    println(listMutable)

    println("---------------------------------------------------------------")

    //Crear lista mutable
    var removeListMutable = mutableListOf(1,2,3,4,5)

    //Quitar elemento de lista mutable
    removeListMutable.remove(3)

    //Imprimir lista mutable
    println(removeListMutable)

    println("---------------------------------------------------------------")

    //Intentar eliminar el elemento "10" de la lista (que no existe)
     removeListMutable.remove(10)

    //Como intamos borrar un elemento que no existe no se hace ninguna modificacion en
    //la lista, simplemente no tine ningun efecto sobre la lista
    println(removeListMutable)

    println("---------------------------------------------------------------")

    //Crear lista mutable
    var listMutable2 = mutableListOf<String>("Felipe","Sara","Rafael","Nicolas","Marta")

    //Indicar el indice del elemento que queremos eliminar en este caso es (Rafael)
    var indexToRemove = 2

    //Eliminar el elemento en el indice indicado
    listMutable2.removeAt(indexToRemove)

    //Imprimir lista mutable
    println(listMutable2)

    println("---------------------------------------------------------------")

    //Crear lista mutable
    var listDelete = mutableListOf(10,20,30,40,50)

    //Borrar la lista completa
    listDelete.clear()

    //Imprimir la lista borrada
    println(listDelete)
}